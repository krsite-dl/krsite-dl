import down.directory as dir

def from_direct(url):
    print("Url: %s" % url)
    dir.dir_handler_alt(url)